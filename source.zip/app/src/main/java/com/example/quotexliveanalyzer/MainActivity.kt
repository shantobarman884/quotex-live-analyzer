package com.example.quotexliveanalyzer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface

class MainActivity : Activity() {
    private val requestCapture = 4107
    private lateinit var preview: ImageView
    private lateinit var status: TextView
    private lateinit var signal: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
            setBackgroundColor(Color.rgb(247, 248, 250))
        }
        root.addView(TextView(this).apply {
            text = "Quotex Live Analyzer"
            textSize = 24f
            setTextColor(Color.rgb(25, 35, 50))
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "স্ক্রিন প্রিভিউ • স্থানীয় বিশ্লেষণ • কোনো স্বয়ংক্রিয় ট্রেড নয়"
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, 8, 0, 16)
        })
        root.addView(Button(this).apply {
            text = "Start screen preview"
            setOnClickListener {
                val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), requestCapture)
            }
        })
        root.addView(Button(this).apply {
            text = "Stop capture"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
                status.text = "স্ক্রিন ক্যাপচার বন্ধ।"
                preview.setImageDrawable(null)
                signal.text = "WAIT — নতুন চার্ট বিশ্লেষণ চলছে না।"
            }
        })
        status = TextView(this).apply {
            text = "স্ট্যাটাস: অনুমতির অপেক্ষায়"
            textSize = 14f
            setPadding(0, 10, 0, 8)
            setTextColor(Color.DKGRAY)
        }
        root.addView(status)
        signal = TextView(this).apply {
            text = "WAIT\nপ্রোটোটাইপে নির্ভরযোগ্য ক্যান্ডেল শনাক্তকরণ নেই।"
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(150, 95, 0))
            setPadding(14, 14, 14, 14)
            setBackgroundColor(Color.rgb(255, 244, 214))
        }
        root.addView(signal)
        preview = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(230, 233, 238))
            contentDescription = "Local screen preview"
        }
        root.addView(preview, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        root.addView(TextView(this).apply {
            text = "গোপনীয়তা: স্ক্রিনে ব্যক্তিগত তথ্য থাকতে পারে। ক্যাপচার অনুমতি ছাড়া শুরু হয় না। ছবি আপলোড বা স্থায়ীভাবে সংরক্ষণ করা হয় না।"
            textSize = 12f
            setTextColor(Color.DKGRAY)
            setPadding(0, 12, 0, 0)
        })
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        ScreenCaptureService.onFrame = { bitmap ->
            runOnUiThread {
                preview.setImageBitmap(bitmap)
                status.text = "স্ট্যাটাস: স্ক্রিন প্রিভিউ চলছে"
                signal.text = "WAIT\nশুধু স্ক্রিন দেখা হচ্ছে; BUY/SELL সংকেত যাচাইকৃত নয়।"
            }
        }
        ScreenCaptureService.onStopped = {
            runOnUiThread { status.text = "স্ক্রিন ক্যাপচার বন্ধ।" }
        }
    }

    @Deprecated("Deprecated API retained for prototype compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == requestCapture) {
            if (resultCode == RESULT_OK && data != null) {
                val serviceIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                }
                startForegroundService(serviceIntent)
                status.text = "অনুমতি দেওয়া হয়েছে; ক্যাপচার শুরু হচ্ছে..."
            } else {
                status.text = "অনুমতি দেওয়া হয়নি; স্ক্রিন ক্যাপচার বন্ধ।"
            }
        }
    }

    override fun onDestroy() {
        ScreenCaptureService.onFrame = null
        super.onDestroy()
    }
}
